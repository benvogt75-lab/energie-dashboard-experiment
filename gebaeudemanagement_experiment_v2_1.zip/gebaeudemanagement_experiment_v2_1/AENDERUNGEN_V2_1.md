# Änderungen V2.1

- Ausschließlich Variante A: PV überall dezentes Gelb, Netzbezug ruhiges Blau.
- Farbverläufe und Leuchteffekte in Variante A reduziert.
- Energieflussanimation: 5 gelbe und 7 blaue Punkte, gleiche Laufzeit (Verhältnis 7:5 ≈ 1,4; Leistungswertverhältnis 24,5:18 ≈ 1,36).
- Variante B und Fragebogen unverändert.
- Funktionstest auf realen Endgeräten steht aus.
